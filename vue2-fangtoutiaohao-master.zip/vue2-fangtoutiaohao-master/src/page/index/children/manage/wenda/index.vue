<template>
    <div id="home">
        <div class="shuju clearfix">
          <div class="shuju_this">
            <h2>
              109
              <span>
                粉丝数
              </span>
            </h2>

          </div>
          <div class="shuju_this">
            <h2>
              109
              <span>
                视频总播放量
              </span>
            </h2>

          </div>
          <div class="shuju_this">
            <h2>
              109
              <span>
                视频总发布数
              </span>
            </h2>

          </div>

        </div>

        <div class="liebiao">

          <el-tabs class="tab_main" v-model="activeName" >
            <el-tab-pane label="热门问题" name="hot">
              <div role="tabPanel" class="tui-tab-panel tui-tab-panel-active"><div><div class="wenda-question"><h3 class="wenda-question-title"><a href="https://www.wukong.com/question/6368723807867240706" target="_blank" rel="noopener">你单曲循环最多的一首歌曲是什么？为什么？</a></h3><p class="wenda-question-content"></p><div class="wenda-question-action"><a class="wenda-question-toanswer" href="https://www.wukong.com/question/6368723807867240706?showAnswerBox=1" target="_blank" rel="noopener">我来回答</a><span>共有2167条回答</span><span class="wenda-question-more">查看更多<i class="iconfont icon-topback reverse" type="topback"></i></span></div><div class="wenda-question-answers"><div class="wenda-comment-bone wenda-answer wenda-answer-first"><div class="wenda-comment-bone-avatar"><a href="https://www.wukong.com/user/?uid=95260909941" target="_blank" rel="noopener noreferrer"><img class="image-avatar" src="http://p3.pstatp.com/thumb/6ede0002358fa2c6aba1"></a></div><div class="wenda-comment-bone-body"><div class="wenda-comment-bone-header"><span class="wenda-comment-bone-title">Grayblue17</span><div class="wenda-comment-bone-subtitle-left"><div><span class="wenda-comment-bone-subtitle-item">诚实善良言出必行且爱你</span></div></div><div class="wenda-comment-bone-subtitle-right"></div></div><div class="wenda-comment-bone-content"><div><p>hi 这里是GrayYe💛我觉得《体面》和《我们》的不同之处大概就在于，我们少了撕心裂肺，多了无能为力。这大概就是刚刚分手和分手十年的差别。“后来的我，离开了他，永远的离开了他，十年的感情不过寥寥几句话。后来的我，嫁给了一个很普通的人，没有他的浪漫，却有不一样的温暖。”—鱼大叔U...<span class="expandable-comment-expand">展开</span></p><img class="wenda-answer-abstract-img" src="http://p3.pstatp.com/list/7e5d00007eda46336bb8" alt=""></div></div><div class="wenda-comment-bone-actions"><div class="wenda-comment-bone-actions-left"><div></div></div><div class="wenda-comment-bone-actions-right"><div></div></div></div></div></div></div></div><div class="wenda-question"><h3 class="wenda-question-title"><a href="https://www.wukong.com/question/6529262322278465800" target="_blank" rel="noopener">杜蕾斯的借势正月习俗海报，文案内容有哪些？</a></h3><p class="wenda-question-content"></p><div class="wenda-question-action"><a class="wenda-question-toanswer" href="https://www.wukong.com/question/6529262322278465800?showAnswerBox=1" target="_blank" rel="noopener">我来回答</a><span>共有7条回答</span><span class="wenda-question-more">查看更多<i class="iconfont icon-topback reverse" type="topback"></i></span></div><div class="wenda-question-answers"><div class="wenda-comment-bone wenda-answer wenda-answer-first"><div class="wenda-comment-bone-avatar"><a href="https://www.wukong.com/user/?uid=6406006831" target="_blank" rel="noopener noreferrer"><img class="image-avatar" src="http://p1.pstatp.com/thumb/59420004c23759a157c5"></a></div><div class="wenda-comment-bone-body"><div class="wenda-comment-bone-header"><span class="wenda-comment-bone-title">叶小鱼跑跑跑</span><div class="wenda-comment-bone-subtitle-left"><div><span class="wenda-comment-bone-subtitle-item">《新媒体文案创作与传播》作者</span></div></div><div class="wenda-comment-bone-subtitle-right"></div></div><div class="wenda-comment-bone-content"><div><p>当新年里第一个月来临时，大家依旧在享受正月里的七天假期，吃好喝好过年好的时候，杜蕾斯却勤勤恳恳地站在一线的文案岗位上，在大年初一到初七的每天都发出了同一画风的海报文案，以下是这些海报和文案内容。1.大年初一，摸摸头，新年讨个好彩头。2.大年初二，宜串门，过年多去探探门。3.大年初...<span class="expandable-comment-expand">展开</span></p><img class="wenda-answer-abstract-img" src="http://p3.pstatp.com/list/6c2a0001cb2837abbe36" alt=""></div></div><div class="wenda-comment-bone-actions"><div class="wenda-comment-bone-actions-left"><div></div></div><div class="wenda-comment-bone-actions-right"><div></div></div></div></div></div></div></div><div class="wenda-question"><h3 class="wenda-question-title"><a href="https://www.wukong.com/question/6499231748642046221" target="_blank" rel="noopener">如何评价《奇门遁甲》？</a></h3><p class="wenda-question-content">你给多少分？</p><div class="wenda-question-action"><a class="wenda-question-toanswer" href="https://www.wukong.com/question/6499231748642046221?showAnswerBox=1" target="_blank" rel="noopener">我来回答</a><span>共有129条回答</span><span class="wenda-question-more">查看更多<i class="iconfont icon-topback reverse" type="topback"></i></span></div><div class="wenda-question-answers"><div class="wenda-comment-bone wenda-answer wenda-answer-first"><div class="wenda-comment-bone-avatar"><a href="https://www.wukong.com/user/?uid=70492763442" target="_blank" rel="noopener noreferrer"><img class="image-avatar" src="http://p3.pstatp.com/thumb/46c30011ab60f44daf89"></a></div><div class="wenda-comment-bone-body"><div class="wenda-comment-bone-header"><span class="wenda-comment-bone-title">大神小说</span><div class="wenda-comment-bone-subtitle-left"><div><span class="wenda-comment-bone-subtitle-item">大神行天下，小说天下事！</span></div></div><div class="wenda-comment-bone-subtitle-right"></div></div><div class="wenda-comment-bone-content"><div><p>这部电影说明一个名导可能成就经典，两个名导合作创造烂片。比如，徐克和袁和平——《奇门遁甲》徐克和周星驰——《西游伏妖篇》（ps:柳岩的影视之路已经走歪了，如今已经沦为知名卖肉演员！）</p><img class="wenda-answer-abstract-img" src="http://p3.pstatp.com/list/7e590000db428adcaa5f" alt=""></div></div><div class="wenda-comment-bone-actions"><div class="wenda-comment-bone-actions-left"><div></div></div><div class="wenda-comment-bone-actions-right"><div></div></div></div></div></div></div></div><div class="wenda-question"><h3 class="wenda-question-title"><a href="https://www.wukong.com/question/6446222457429819661" target="_blank" rel="noopener">如何看待人类给动物杂交？</a></h3><p class="wenda-question-content">我还是一名大一学生，昨晚老师讲课，讲到有些所谓的科学研究者给动物杂交，我心里很不是滋味。</p><div class="wenda-question-action"><a class="wenda-question-toanswer" href="https://www.wukong.com/question/6446222457429819661?showAnswerBox=1" target="_blank" rel="noopener">我来回答</a><span>共有68条回答</span><span class="wenda-question-more">查看更多<i class="iconfont icon-topback reverse" type="topback"></i></span></div><div class="wenda-question-answers"><div class="wenda-comment-bone wenda-answer wenda-answer-first"><div class="wenda-comment-bone-avatar"><a href="https://www.wukong.com/user/?uid=78892493062" target="_blank" rel="noopener noreferrer"><img class="image-avatar" src="http://p3.pstatp.com/thumb/594b0001f2041e40d54d"></a></div><div class="wenda-comment-bone-body"><div class="wenda-comment-bone-header"><span class="wenda-comment-bone-title">万物未解之谜</span><div class="wenda-comment-bone-subtitle-left"><div><span class="wenda-comment-bone-subtitle-item">这里为您提供最新最全的万物秘辛，让我们来一起探索宇宙奥秘吧！</span></div></div><div class="wenda-comment-bone-subtitle-right"></div></div><div class="wenda-comment-bone-content"><div><p>凡是都有两面性，科学自然也不列外，有些科学家确实是秘密研究这种东西，杂交！虽然这种研究是被禁止的，但如果有人要研究，你哪里知道。总之，在这方面上的研究，历史上，乃至现在，都是存在的。来说说前段时间发生的吧，美国搞出一个人羊杂交种又叫做嵌合体，这是已经实现了，为了就是有一天能够有代...<span class="expandable-comment-expand">展开</span></p><img class="wenda-answer-abstract-img" src="http://p3.pstatp.com/list/7572000319c53c099b9b" alt=""></div></div><div class="wenda-comment-bone-actions"><div class="wenda-comment-bone-actions-left"><div></div></div><div class="wenda-comment-bone-actions-right"><div></div></div></div></div></div></div></div><div class="wenda-question"><h3 class="wenda-question-title"><a href="https://www.wukong.com/question/6477168925174923534" target="_blank" rel="noopener">假如复仇者联盟里的英雄全部换成国内明星，你觉得谁演谁最合适？</a></h3><p class="wenda-question-content">雷神的话，我想已经有合适的人选了！
                徐……</p><div class="wenda-question-action"><a class="wenda-question-toanswer" href="https://www.wukong.com/question/6477168925174923534?showAnswerBox=1" target="_blank" rel="noopener">我来回答</a><span>共有44条回答</span><span class="wenda-question-more">查看更多<i class="iconfont icon-topback reverse" type="topback"></i></span></div><div class="wenda-question-answers"><div class="wenda-comment-bone wenda-answer wenda-answer-first"><div class="wenda-comment-bone-avatar"><a href="https://www.wukong.com/user/?uid=59442500206" target="_blank" rel="noopener noreferrer"><img class="image-avatar" src="http://p1.pstatp.com/thumb/1bf6001d98601dd941a7"></a></div><div class="wenda-comment-bone-body"><div class="wenda-comment-bone-header"><span class="wenda-comment-bone-title">CestLaVie161920951</span><div class="wenda-comment-bone-subtitle-left"><div><span class="wenda-comment-bone-subtitle-item">白茶清欢无别事 我在等风也等你</span></div></div><div class="wenda-comment-bone-subtitle-right"></div></div><div class="wenda-comment-bone-content"><div><p>复仇者联盟，网上出了一个帖子让人爆笑不断，中国明星如果是以复仇者联盟到底会是什么样子呢，有大神把中国明星P图到了复仇者联盟身上，这毫无违和感的样子的确很养眼。有一个网友把复仇者联盟里面的角色都修改成了中国的明星，可以说网友也是呕心沥血的做成的，每个角度完美贴合，成品图帅气炫酷，但...<span class="expandable-comment-expand">展开</span></p><img class="wenda-answer-abstract-img" src="http://p3.pstatp.com/list/dd500012832317c2f23" alt=""></div></div><div class="wenda-comment-bone-actions"><div class="wenda-comment-bone-actions-left"><div></div></div><div class="wenda-comment-bone-actions-right"><div></div></div></div></div></div></div></div><div class="wenda-question"><h3 class="wenda-question-title"><a href="https://www.wukong.com/question/6469390860139102477" target="_blank" rel="noopener">你见过最孤独的一句话是什么？</a></h3><p class="wenda-question-content"></p><div class="wenda-question-action"><a class="wenda-question-toanswer" href="https://www.wukong.com/question/6469390860139102477?showAnswerBox=1" target="_blank" rel="noopener">我来回答</a><span>共有8430条回答</span><span class="wenda-question-more">查看更多<i class="iconfont icon-topback reverse" type="topback"></i></span></div><div class="wenda-question-answers"><div class="wenda-comment-bone wenda-answer wenda-answer-first"><div class="wenda-comment-bone-avatar"><a href="https://www.wukong.com/user/?uid=5890010831" target="_blank" rel="noopener noreferrer"><img class="image-avatar" src="http://p3.pstatp.com/thumb/4aee0005aed92c88a02f"></a></div><div class="wenda-comment-bone-body"><div class="wenda-comment-bone-header"><span class="wenda-comment-bone-title">沙栗</span><div class="wenda-comment-bone-subtitle-left"><div><span class="wenda-comment-bone-subtitle-item">我想坚持一生的事：读书 写字  公号：沙栗的读书集</span></div></div><div class="wenda-comment-bone-subtitle-right"></div></div><div class="wenda-comment-bone-content"><div><p>村上春树的两句话：1、希望你下辈子不要改名，这样我好找你一点。写尽爱而不得的忧伤！相信很多深爱过却又不得不分离或者说深爱过却始终未曾得到过的人一定能够感同身受。不管怎么样，始终还是爱着一个人，甚至渴望来生能够在一起！2、要平安无事的活下去。对于曾经长时间一个人生活的人来说会感触更...<span class="expandable-comment-expand">展开</span></p><img class="wenda-answer-abstract-img" src="" alt=""></div></div><div class="wenda-comment-bone-actions"><div class="wenda-comment-bone-actions-left"><div></div></div><div class="wenda-comment-bone-actions-right"><div></div></div></div></div></div></div></div><div class="wenda-question"><h3 class="wenda-question-title"><a href="https://www.wukong.com/question/6453684360045396238" target="_blank" rel="noopener">电视剧中有哪些穿帮镜头？</a></h3><p class="wenda-question-content"></p><div class="wenda-question-action"><a class="wenda-question-toanswer" href="https://www.wukong.com/question/6453684360045396238?showAnswerBox=1" target="_blank" rel="noopener">我来回答</a><span>共有109条回答</span><span class="wenda-question-more">查看更多<i class="iconfont icon-topback reverse" type="topback"></i></span></div><div class="wenda-question-answers"><div class="wenda-comment-bone wenda-answer wenda-answer-first"><div class="wenda-comment-bone-avatar"><a href="https://www.wukong.com/user/?uid=6393685713" target="_blank" rel="noopener noreferrer"><img class="image-avatar" src="http://p3.pstatp.com/thumb/1a6c000537fe89cb5c9d"></a></div><div class="wenda-comment-bone-body"><div class="wenda-comment-bone-header"><span class="wenda-comment-bone-title">龙堂娱乐</span><div class="wenda-comment-bone-subtitle-left"><div><span class="wenda-comment-bone-subtitle-item">爱家驹，爱Beyond，在这灰色轨迹的路上，谁伴我闯荡！</span></div></div><div class="wenda-comment-bone-subtitle-right"></div></div><div class="wenda-comment-bone-content"><div><p>谢谢邀请！郑爽在近几年也出演了不少影视剧，也取得了非常不错的成绩，比如她的杨洋一起主演的青春偶像剧《微微一笑很倾城》就非常受观众的欢迎，也勾起了大家对自己青春的美好回忆，但是她所演的这几部剧中也是有穿帮的，下面就让我们盘点一下那些可爱的镜头吧，不为吐槽，只为娱乐！这部剧就是刚刚说...<span class="expandable-comment-expand">展开</span></p><img class="wenda-answer-abstract-img" src="http://p3.pstatp.com/list/756e0005722abc7551ea" alt=""></div></div><div class="wenda-comment-bone-actions"><div class="wenda-comment-bone-actions-left"><div></div></div><div class="wenda-comment-bone-actions-right"><div></div></div></div></div></div></div></div><div class="wenda-question"><h3 class="wenda-question-title"><a href="https://www.wukong.com/question/6514813713373987080" target="_blank" rel="noopener">男生身高长到一米几算好看？</a></h3><p class="wenda-question-content"></p><div class="wenda-question-action"><a class="wenda-question-toanswer" href="https://www.wukong.com/question/6514813713373987080?showAnswerBox=1" target="_blank" rel="noopener">我来回答</a><span>共有265条回答</span><span class="wenda-question-more">查看更多<i class="iconfont icon-topback reverse" type="topback"></i></span></div><div class="wenda-question-answers"><div class="wenda-comment-bone wenda-answer wenda-answer-first"><div class="wenda-comment-bone-avatar"><a href="https://www.wukong.com/user/?uid=52660589251" target="_blank" rel="noopener noreferrer"><img class="image-avatar" src="http://p3.pstatp.com/thumb/5d420012128bf55326b4"></a></div><div class="wenda-comment-bone-body"><div class="wenda-comment-bone-header"><span class="wenda-comment-bone-title">白这个颜色</span><div class="wenda-comment-bone-subtitle-left"><div><span class="wenda-comment-bone-subtitle-item">本科 ，对悟空问答深怀纯洁感情</span></div></div><div class="wenda-comment-bone-subtitle-right"></div></div><div class="wenda-comment-bone-content"><div><p>其实男生身高好不好看，不是测量仪可以说得算，要经过智能测量，那就是女生的眼睛。一米几好看呢？这要看存折的数位，位数多的，身高就好看，八位数的比七位数好看，九位数比八位数好看。有人会说小编胡说，当然也有不那么现实的女生，不过不能持久，激情过了，还得看几位数。不说高富美，至少有爱情还...<span class="expandable-comment-expand">展开</span></p><img class="wenda-answer-abstract-img" src="" alt=""></div></div><div class="wenda-comment-bone-actions"><div class="wenda-comment-bone-actions-left"><div></div></div><div class="wenda-comment-bone-actions-right"><div></div></div></div></div></div></div></div><div class="wenda-question"><h3 class="wenda-question-title"><a href="https://www.wukong.com/question/6539711654454624519" target="_blank" rel="noopener">巨龟为何常被在古井中发现？</a></h3><p class="wenda-question-content"></p><div class="wenda-question-action"><a class="wenda-question-toanswer" href="https://www.wukong.com/question/6539711654454624519?showAnswerBox=1" target="_blank" rel="noopener">我来回答</a><span>共有136条回答</span><span class="wenda-question-more">查看更多<i class="iconfont icon-topback reverse" type="topback"></i></span></div><div class="wenda-question-answers"><div class="wenda-comment-bone wenda-answer wenda-answer-first"><div class="wenda-comment-bone-avatar"><a href="https://www.wukong.com/user/?uid=85316722930" target="_blank" rel="noopener noreferrer"><img class="image-avatar" src="http://p1.pstatp.com/thumb/6ee10002092168b48e87"></a></div><div class="wenda-comment-bone-body"><div class="wenda-comment-bone-header"><span class="wenda-comment-bone-title">墨辞</span><div class="wenda-comment-bone-subtitle-left"><div><span class="wenda-comment-bone-subtitle-item">散文随笔！自攥小说！分享经典诗词名句！</span></div></div><div class="wenda-comment-bone-subtitle-right"></div></div><div class="wenda-comment-bone-content"><div><p>这个问题算是悖论吧！都知道千年王八万年龟！可想而知，龟的寿命可谓是很长的！千年王八，万年龟为何巨龟都在古井中被发现？这只能说是相对而言！大江大海的巨龟太多了！而因为乌龟寿命长，而井就在人的生活范围内！所以相对江海来说，在井里发现巨龟的几率相对而言自然就要大的多了！而题主说的这个事...<span class="expandable-comment-expand">展开</span></p><img class="wenda-answer-abstract-img" src="http://p3.pstatp.com/list/75700002da44e36e01a7" alt=""></div></div><div class="wenda-comment-bone-actions"><div class="wenda-comment-bone-actions-left"><div></div></div><div class="wenda-comment-bone-actions-right"><div></div></div></div></div></div></div></div><div class="wenda-action"><span class="wenda-action-refresh">换一批<i type="refresh" class="iconfont icon-refresh "></i></span><a href="https://www.wukong.com/?from=pgc" class="wenda-action-more" target="_blank" rel="noopener">查看更多<i type="topback" class="iconfont icon-topback "></i></a></div></div></div>
            </el-tab-pane>
            <el-tab-pane label="问题邀请" name="yaoqing">

            </el-tab-pane>
          </el-tabs>

        </div>
    </div>
</template>
<script>
export default {
    name: 'home',
    data() {
        return {
          activeName: 'hot',
          invTime: 2000,
          slides: [
            {
              src: require('@/assets/img/slide_1.jpg'),
              // 打包过后会根据根据打包规则重新定义位置。不会出现找不到图片的问题    **图片通过JS引入都必须  require()
              title: 'xxx1',
              href: 'detail/analysis'
            },
            {
              src: require('@/assets/img/slide_1.jpg'),
              title: 'xxx2',
              href: 'detail/count'
            }
          ]
        }
    },
    computed: {

    },
    methods: {

    },
    mounted() {
      // console.log(this.$route.name)  接收来自子级传递的选项卡name
    }
}
</script>
<style lang='scss' scoped="scoped">
  @import "../../../../../assets/css/tongyong";
#home {
  .shuju{
    .shuju_this{
      @include box-show(148px,290px);
      float: left;
      margin-right: 18px;
      h2{
        position: relative;
        text-align: center;
        line-height: 120px;
        @include font-tongyong(40px,red);
      }
      span{
        position: absolute;
        @include font-tongyong(16px,#222);
        left: 42%;
        top: 35%;
      }
    }
  }
  .el-tabs__header{
    font-size: 16px;
    padding: 32px 40px 0;
    border-bottom: 1px solid #e8e8e8;
  }
  .slide{
    @include box-show();
    overflow: hidden;
    margin-top: 24px;
    height: 124px;
    width: 906px;
  }
  .liebiao{
    @include box-show();
    margin-top: 24px;

    .wenda-poster{display:block;margin:20px 24px}.wenda-poster img{display:block;width:100%}.wenda-tags{padding-bottom:20px}.wenda-tags .tui-tab-list{border-top:none;font-size:16px!important;height:auto;line-height:1.2;border-bottom:1px solid #e8e8e8!important}.wenda-tags .tui-tab-list .tui-tab{padding-top:32px;padding-bottom:12px}.wenda-tags .tui-tab-list .tui-tab:not(.tui-tab-selected){color:inherit}.wenda-tags .tui-tab-list .tui-tab:hover{opacity:.6;-webkit-transition:all .2s;-moz-transition:all .2s;transition:all .2s}.wenda-tags .tui-tab-list .tui-tab:first-child{margin-left:40px}.wenda-tags .tui-tab-list .tui-tab-selected{-webkit-transform:translateY(1px);-moz-transform:translateY(1px);-ms-transform:translateY(1px);transform:translateY(1px);border-bottom:2px solid #f85959;border-top:none} .tui-tab-panel{padding:0 40px}.wenda-action{font-size:13px;color:#222;text-align:center;margin-top:32px}.wenda-action .iconfont{font-size:11px;color:#222;margin-left:8px}.wenda-action a{color:#222}.wenda-action-refresh{margin-right:64px;cursor:pointer}.wenda-action-more{cursor:pointer}.wenda-action-more .iconfont{display:inline-block;-webkit-transform:rotate(90deg);-moz-transform:rotate(90deg);-ms-transform:rotate(90deg);transform:rotate(90deg)}.wenda .tui-pagination-container{text-align:center;margin-top:68px}.wenda-dialog-footer{text-align:center;padding:10px}.wenda-dialog-footer .tui-btn{font-weight:400}

    .wenda-question{font-size:14px;padding:18px 0;border-bottom:1px solid #e8e8e8}.wenda-question-title{color:#222;font-size:16px;font-weight:700}.wenda-question-title a{color:#222}.wenda-question-badge{display:inline-block;width:60px;height:20px;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;vertical-align:top;text-align:center;color:#fff;line-height:20px;font-weight:700;margin-left:4px}.wenda-question-badge-blue{background-color:#2a90d7}.wenda-question-badge-red{background-color:#f85959}.wenda-question-content{color:#999;line-height:22px}.wenda-question-action{color:#999;margin-top:10px;margin-bottom:16px}.wenda-question-action .iconfont{font-size:12px}.garr-container .wenda-question-toanswer{display:inline-block;line-height:20px;margin-right:8px;padding:0 8px;color:#2a90d7;cursor:pointer;border:1px solid #2a90d7;-webkit-border-radius:20px;-moz-border-radius:20px;border-radius:20px;text-shadow:0 1px 0 #fff}.wenda-question-more{margin-left:8px;cursor:pointer}.wenda-question-more .iconfont{display:inline-block;margin-left:6px}.wenda-question-more .iconfont.reverse{-webkit-transform:rotate(180deg);-moz-transform:rotate(180deg);-ms-transform:rotate(180deg);transform:rotate(180deg)}.wenda-answer{padding:14px 10px 16px 14px;margin-top:0}.wenda-answer-first{background-color:#f4f5f6;border:1px solid #e8e8e8;-webkit-border-radius:4px 4px 0 0;-moz-border-radius:4px 4px 0 0;border-radius:4px 4px 0 0}.wenda-answer.comment-bone{border-bottom:none}.wenda-answer .comment-bone-avatar{width:40px;height:40px;left:5px}.wenda-answer .comment-bone-body{padding-left:53px}.wenda-answer .comment-bone-subtitle{font-size:14px;color:#222}.wenda-answer .comment-bone-time{display:block;float:none;color:#999}.wenda-answer .comment-bone-content{margin-top:8px;margin-bottom:0}.wenda-answer-abstract-img{display:block;max-width:100%;margin-top:8px}.wenda-answer .expandable-comment-expand{color:#2a90d7;cursor:pointer}
  }

}

</style>
