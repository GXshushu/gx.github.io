<template>
    <div id="sixin">

    </div>
</template>
<script>
export default {
    name: 'sixin',
    data() {
        return {
          invTime: 2000,
        }
    },
    computed: {

    },
    methods: {

    },
    mounted() {
      // console.log(this.$route.name)  接收来自子级传递的选项卡name
    }
}
</script>
<style lang='scss'>
@import "./../../../../assets/css/tongyong";
#sixin {


}

</style>
