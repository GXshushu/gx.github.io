<template>

  <div class="garr-container">
    <div class="pgc-audience-property garr-container-white">
      <div class="exponential-sub-title exponential-sub-title-first">性别比例</div>
      <div class="exponential-content">
        <div class="audience-bar">
          <div class="bar-wrap">
            <div class="bar-inner" style="width: 14.94%;"></div>
          </div>
          <div class="bar-note"><span class="bar-note-sharp orange"></span><span class="bar-note-title">女(14.94%)</span><span
            class="bar-note-sharp blue"></span><span class="bar-note-title">男(85.06%)</span></div>
        </div>
      </div>
      <div class="exponential-sub-title">年龄分布</div>
      <div class="exponential-content">
        <div class="audience-age-chart">
          <div class=""
               style="height: 330px; padding-left: 20px; -moz-user-select: none; position: relative; background: transparent none repeat scroll 0% 0%;"
               _echarts_instance_="ec_1524550747676">
            <div id="myChart1"
              style="position: relative; overflow: hidden; width: 624px; height: 330px; padding: 0px; margin: 0px; border-width: 0px; cursor: default;">

            </div>
            <div
              style="position: absolute; display: none; border-style: solid; white-space: nowrap; z-index: 9999999; transition: left 0.4s cubic-bezier(0.23, 1, 0.32, 1) 0s, top 0.4s cubic-bezier(0.23, 1, 0.32, 1) 0s; background-color: rgba(50, 50, 50, 0.7); border-width: 0px; border-color: rgb(51, 51, 51); border-radius: 4px; color: rgb(255, 255, 255); font: 14px/21px Microsoft YaHei; padding: 5px; left: 146px; top: 157px;">
              0-18<br>数量占比 : 0%
            </div>
          </div>
        </div>
        <div class="audience-age-list">
          <table class="content-table">
            <thead>
            <tr>
              <th>年龄</th>
              <th>粉丝占比</th>
            </tr>
            </thead>
            <tbody>
            <tr>
              <td>0-18</td>
              <td>0%</td>
            </tr>
            <tr>
              <td>18-23</td>
              <td>69.01%</td>
            </tr>
            <tr>
              <td>24-30</td>
              <td>21.13%</td>
            </tr>
            <tr>
              <td>31-40</td>
              <td>9.86%</td>
            </tr>
            <tr>
              <td>41-50</td>
              <td>0%</td>
            </tr>
            <tr>
              <td>50+</td>
              <td>0%</td>
            </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="exponential-sub-title">地域分布</div>
      <div class="exponential-content">
        <div class="audience-map-chart">
          <div class=""
               style="height: 450px; -moz-user-select: none; position: relative; background: transparent none repeat scroll 0% 0%;"
               _echarts_instance_="ec_1524550747677">
            <div id="myChart2"
              style="position: relative; overflow: hidden; width: 600px; height: 450px; padding: 0px; margin: 0px; border-width: 0px;">

            </div>
            <div></div>
          </div>
        </div>
        <div class="audience-map-pie-chart">
          <div class=""
               style="height: 350px; -moz-user-select: none; position: relative; background: transparent none repeat scroll 0% 0%;"
               _echarts_instance_="ec_1524550747678">
            <div id="myChart3"
              style="position: relative; overflow: hidden; width: 644px; height: 350px; padding: 0px; margin: 0px; border-width: 0px;">

            </div>
            <div></div>
          </div>
        </div>
        <div class="audience-map-list">
          <table class="content-table">
            <thead>
            <tr>
              <th>省份</th>
              <th>粉丝占比</th>
            </tr>
            </thead>
          </table>
          <div class="audience-map-list-content">
            <table class="content-table">
              <tbody>
              <tr>
                <td>广东</td>
                <td>23.81%</td>
              </tr>
              <tr>
                <td>山东</td>
                <td>8.33%</td>
              </tr>
              <tr>
                <td>河南</td>
                <td>7.14%</td>
              </tr>
              <tr>
                <td>安徽</td>
                <td>5.95%</td>
              </tr>
              <tr>
                <td>北京</td>
                <td>4.76%</td>
              </tr>
              <tr>
                <td>黑龙江</td>
                <td>4.76%</td>
              </tr>
              <tr>
                <td>吉林</td>
                <td>3.57%</td>
              </tr>
              <tr>
                <td>山西</td>
                <td>3.57%</td>
              </tr>
              <tr>
                <td>江西</td>
                <td>3.57%</td>
              </tr>
              <tr>
                <td>浙江</td>
                <td>3.57%</td>
              </tr>
              <tr>
                <td>湖北</td>
                <td>3.57%</td>
              </tr>
              <tr>
                <td>湖南</td>
                <td>3.57%</td>
              </tr>
              <tr>
                <td>甘肃</td>
                <td>3.57%</td>
              </tr>
              <tr>
                <td>陕西</td>
                <td>3.57%</td>
              </tr>
              <tr>
                <td>上海</td>
                <td>2.38%</td>
              </tr>
              <tr>
                <td>四川</td>
                <td>2.38%</td>
              </tr>
              <tr>
                <td>贵州</td>
                <td>2.38%</td>
              </tr>
              <tr>
                <td>云南</td>
                <td>1.19%</td>
              </tr>
              <tr>
                <td>内蒙古</td>
                <td>1.19%</td>
              </tr>
              <tr>
                <td>天津</td>
                <td>1.19%</td>
              </tr>
              <tr>
                <td>新疆</td>
                <td>1.19%</td>
              </tr>
              <tr>
                <td>河北</td>
                <td>1.19%</td>
              </tr>
              <tr>
                <td>福建</td>
                <td>1.19%</td>
              </tr>
              <tr>
                <td>辽宁</td>
                <td>1.19%</td>
              </tr>
              <tr>
                <td>重庆</td>
                <td>1.19%</td>
              </tr>
              <tr>
                <td>台湾</td>
                <td>0%</td>
              </tr>
              <tr>
                <td>宁夏</td>
                <td>0%</td>
              </tr>
              <tr>
                <td>广西</td>
                <td>0%</td>
              </tr>
              <tr>
                <td>江苏</td>
                <td>0%</td>
              </tr>
              <tr>
                <td>海南</td>
                <td>0%</td>
              </tr>
              <tr>
                <td>澳门</td>
                <td>0%</td>
              </tr>
              <tr>
                <td>西藏</td>
                <td>0%</td>
              </tr>
              <tr>
                <td>青海</td>
                <td>0%</td>
              </tr>
              <tr>
                <td>香港</td>
                <td>0%</td>
              </tr>
              <tr>
                <td>南海诸岛</td>
                <td>0%</td>
              </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <div class="exponential-sub-title">终端分布</div>
      <div class="exponential-content">
        <div class="audience-bar">
          <div class="bar-wrap">
            <div class="bar-inner" style="width: 93.81%;"></div>
          </div>
          <div class="bar-note"><span class="bar-note-sharp orange"></span><span
            class="bar-note-title">Android(93.81%)</span><span class="bar-note-sharp blue"></span><span
            class="bar-note-title">iOS(6.19%)</span></div>
        </div>
      </div>
      <div class="exponential-sub-title">你的受众都喜欢哪些分类的内容？</div>
      <div class="exponential-content">
        <div class=""
             style="height: 330px; -moz-user-select: none; position: relative; background: transparent none repeat scroll 0% 0%;"
             _echarts_instance_="ec_1524550747679">
          <div id="myChart4"
            style="position: relative; overflow: hidden; width: 824px; height: 330px; padding: 0px; margin: 0px; border-width: 0px;">

          </div>
          <div></div>
        </div>
      </div>
      <div class="exponential-sub-title">你内容里的哪些关键词更受关注？</div>
      <div class="exponential-content">
        <div class=""
             style="height: 330px; -moz-user-select: none; position: relative; background: transparent none repeat scroll 0% 0%;"
             _echarts_instance_="ec_1524550747680">
          <div id="myChart5"
            style="position: relative; overflow: hidden; width: 824px; height: 330px; padding: 0px; margin: 0px; border-width: 0px;">

          </div>
          <div></div>
        </div>
      </div>
      <div class="exponential-sub-title">关注你的人还喜欢哪些头条号？</div>
      <div class="interest-media-list"><a class="interest-media" target="_blank" href="//www.toutiao.com/c/user/4377795668/" rel="noopener noreferrer"><img src="http://p2.pstatp.com/large/3658/7378365093" alt=""><span>新华网</span></a><a class="interest-media" target="_blank" href="//www.toutiao.com/c/user/4595880688/" rel="noopener noreferrer"><img src="http://p3.pstatp.com/large/5205/4571173352" alt=""><span>金羊网</span></a><a class="interest-media" target="_blank" href="//www.toutiao.com/c/user/4492956276/" rel="noopener noreferrer"><img src="http://p2.pstatp.com/large/4306/2602403105" alt=""><span>央视新闻</span></a><a class="interest-media" target="_blank" href="//www.toutiao.com/c/user/1781205550/" rel="noopener noreferrer"><img src="http://p0.pstatp.com/large/1757/1226119251" alt=""><span>中国地震台网速报</span></a><a class="interest-media" target="_blank" href="//www.toutiao.com/c/user/3401211262/" rel="noopener noreferrer"><img src="http://p1.pstatp.com/large/1102/7091793237" alt=""><span>我就是我</span></a><a class="interest-media" target="_blank" href="//www.toutiao.com/c/user/3357849143/" rel="noopener noreferrer"><img src="http://p2.pstatp.com/thumb/1027/8395066378" alt=""><span>北京晨报</span></a><a class="interest-media" target="_blank" href="//www.toutiao.com/c/user/4433966661/" rel="noopener noreferrer"><img src="http://p3.pstatp.com/large/3794/1965137706" alt=""><span>南都娱乐周刊</span></a><a class="interest-media" target="_blank" href="//www.toutiao.com/c/user/3507130514/" rel="noopener noreferrer"><img src="http://p10.pstatp.com/large/364500122cf11186f98d" alt=""><span>荆楚网</span></a><a class="interest-media" target="_blank" href="//www.toutiao.com/c/user/3918675401/" rel="noopener noreferrer"><img src="http://p2.pstatp.com/large/2113/3185756059" alt=""><span>结婚那点事儿</span></a><a class="interest-media" target="_blank" href="//www.toutiao.com/c/user/3267817930/" rel="noopener noreferrer"><img src="http://p3.pstatp.com/large/801/943652037" alt=""><span>青年时报</span></a><a class="interest-media" target="_blank" href="//www.toutiao.com/c/user/4644596221/" rel="noopener noreferrer"><img src="http://p1.pstatp.com/large/5677/4633951464" alt=""><span>新京报政事儿</span></a><a class="interest-media" target="_blank" href="//www.toutiao.com/c/user/3707148061/" rel="noopener noreferrer"><img src="http://p1.pstatp.com/large/1647/1784215473" alt=""><span>新疆晨报</span></a></div>
      <span></span></div>
  </div>

</template>
<script>
import echarts from 'echarts'
import china from 'echarts/map/js/china.js'

export default {
    name: 'fensi',
    data() {
        return {
          data: [{
            name: '2256',
            value: 2256
          }, {
            name: '578',
            value: 578
          }, {
            name: '744',
            value: 744
          }, {
            name: '806',
            value: 806
          }, {
            name: '336',
            value: 336
          }, {
            name: '325',
            value: 325
          }, {
            name: '487',
            value: 487
          }, {
            name: '343',
            value: 343
          }, {
            name: '432',
            value: 432
          }, {
            name: '273',
            value: 273
          }, {
            name: '1055',
            value: 1055
          }, {
            name: '590',
            value: 590
          }, {
            name: '319',
            value: 319
          }, {
            name: '349',
            value: 349
          }, {
            name: '126',
            value: 126
          }, {
            name: '97',
            value: 97
          }, {
            name: '201',
            value: 201
          }, {
            name: '398',
            value: 398
          }, {
            name: '795',
            value: 795
          }, {
            name: '655',
            value: 655
          }, {
            name: '295',
            value: 295
          }, {
            name: '311',
            value: 311
          }, {
            name: '993',
            value: 993
          }, {
            name: '601',
            value: 601
          }, {
            name: '275',
            value: 275
          }, {
            name: '317',
            value: 317
          }, {
            name: '1000',
            value: 1000
          }, {
            name: '186',
            value: 186
          }, {
            name: '261',
            value: 261
          }, {
            name: '132',
            value: 132
          }, {
            name: '18',
            value: 18
          }, {
            name: '11',
            value: 11
          }],
          geoCoordMap: {
            '2256': [116.46, 39.92],
            '578': [121.29, 31.14],
            '744': [117.2, 39.13],
            '806': [106.32, 29.32],
            '336': [126.41, 45.45],
            '325': [125.19, 43.52],
            '487': [123.24, 41.50],
            '343': [111.48, 40.49],
            '432': [114.28, 38.02],
            '273': [112.34, 37.52],
            '1055': [117, 36.38],
            '590': [113.42, 34.48],
            '319': [108.54, 34.16],
            '349': [103.49, 36.03],
            '126': [106.16, 38.20],
            '97': [101.45, 36.38],
            '201': [87.36, 43.48],
            '398': [117.18, 31.51],
            '795': [118.50, 32.02],
            '655': [120.09, 30.14],
            '295': [113, 28.11],
            '311': [115.52, 28.41],
            '993': [114.21, 30.37],
            '601': [104.05, 30.39],
            '275': [106.42, 26.35],
            '317': [119.18, 26.05],
            '1000': [113.15, 23.08],
            '186': [110.20, 20.02],
            '261': [108.20, 22.48],
            '132': [102.41, 25],
            '18': [91.10, 29.40],
            '11': [114.10, 22.18]
          }
        }
    },
    computed: {

    },
    methods: {
      convertData() {
        var res = []
        for (var i = 0; i < this.data.length; i++) {
          var geoCoord = this.geoCoordMap[this.data[i].name]
          if (geoCoord) {
            res.push({
              name: this.data[i].name,
              value: geoCoord.concat(this.data[i].value)
            })
          }
        }
        return res
      },
      drawLine() {
        let myChart = echarts.init(document.getElementById('myChart1'))
        myChart.setOption({
          color: ['#3398DB'],
          tooltip: {
            trigger: 'axis',
            axisPointer: {            // 坐标轴指示器，坐标轴触发有效
              type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
            }
          },
          grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
          },
          xAxis: [
            {
              type: 'category',
              data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
              axisTick: {
                alignWithLabel: true
              }
            }
          ],
          yAxis: [
            {
              type: 'value'
            }
          ],
          series: [
            {
              name: '直接访问',
              type: 'bar',
              barWidth: '60%',
              data: [10, 52, 200, 334, 390, 330, 220]
            }
          ]
        })
      },
      drawLine2() {
        let myChart = echarts.init(document.getElementById('myChart2'))
        myChart.setOption({
          title: {
            text: '全国会员分布',
            subtext: '（单位/人）',

            x: 'center',
            textStyle: {
              color: '#424242'
            }
          },
          tooltip: {
            show: false
          },
          visualMap: {
            min: 0,
            max: 1500,
            left: '-100%',
            top: 'bottom',
            text: ['High', 'Low'],
            seriesIndex: [1],
            inRange: {
              color: ['#e0ffff', '#006edd']
            },
            calculable: false
          },
          geo: {
            map: 'china',
            roam: 'move',
            // scaleLimit:{
            //   max:'1.2',
            //   min:'0.7'
            // },
            label: {
              normal: {
                show: true,
                textStyle: {
                  color: 'rgba(0,0,0,0.6)'
                }
              }
            },
            itemStyle: {
              normal: {
                borderColor: 'rgba(0, 0, 0, 0.2)'
              },
              emphasis: {
                areaColor: null,
                shadowOffsetX: 0,
                shadowOffsetY: 0,
                shadowBlur: 20,
                borderWidth: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          },
          series: [{
            type: 'scatter',
            coordinateSystem: 'geo',
            data: this.convertData(this.data),
            symbolSize: 20,
            symbol: 'path://M35.025,17.608c-5.209-4.786-11.483-2.301-15.303-4.281v-1.482c0-0.41-0.333-0.743-0.743-0.743c-0.411,0-0.743,0.333-0.743,0.743v24.682c-1.855,0.104-3.261,0.59-3.261,1.175c0,0.661,1.793,1.197,4.005,1.197c2.21,0,4.003-0.536,4.003-1.197c0-0.585-1.405-1.071-3.261-1.175V26.151C24.575,24.573,28.408,17.166,35.025,17.608z',
            symbolRotate: 0,
            symbolOffset: ['50%', '-100%'],
            label: {
              normal: {
                formatter: '{b}',
                position: 'top',
                show: false,
                textStyle: {
                  color: '#000000',
                  fontSize: 16
                }

              },
              emphasis: {
                show: false
              }
            },
            itemStyle: {
              normal: {
                color: '#F06C00'
              }
            }
          }, {
            name: '个人会员数量',
            type: 'map',
            geoIndex: 0,
            tooltip: {
              show: true
            },
            data: [{
              name: '北京',
              value: 2256
            }, {
              name: '天津',
              value: 744
            }, {
              name: '上海',
              value: 578
            }, {
              name: '重庆',
              value: 806
            }, {
              name: '河北',
              value: 432
            }, {
              name: '河南',
              value: 590
            }, {
              name: '云南',
              value: 132
            }, {
              name: '辽宁',
              value: 487
            }, {
              name: '黑龙江',
              value: 336
            }, {
              name: '湖南',
              value: 295
            }, {
              name: '安徽',
              value: 398
            }, {
              name: '山东',
              value: 1055
            }, {
              name: '新疆',
              value: 201
            }, {
              name: '江苏',
              value: 795
            }, {
              name: '浙江',
              value: 655
            }, {
              name: '江西',
              value: 311
            }, {
              name: '湖北',
              value: 993
            }, {
              name: '广西',
              value: 261
            }, {
              name: '甘肃',
              value: 349
            }, {
              name: '山西',
              value: 273
            }, {
              name: '内蒙古',
              value: 343
            }, {
              name: '陕西',
              value: 319
            }, {
              name: '吉林',
              value: 325
            }, {
              name: '福建',
              value: 317
            }, {
              name: '贵州',
              value: 275
            }, {
              name: '广东',
              value: 1000
            }, {
              name: '青海',
              value: 97
            }, {
              name: '西藏',
              value: 18
            }, {
              name: '四川',
              value: 601
            }, {
              name: '宁夏',
              value: 126
            }, {
              name: '海南',
              value: 186
            }, {
              name: '台湾',
              value: 0
            }, {
              name: '香港',
              value: 11
            }, {
              name: '澳门',
              value: 0
            }]
          }]
        })
      },
      drawLine3() {
        let myChart = echarts.init(document.getElementById('myChart3'))
        myChart.setOption({
          tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)'
          },
          series: [{
            name: '库存情况',
            type: 'pie',
            radius: '68%',
            center: ['50%', '50%'],
            clockwise: false,
            data: [{
              value: 45,
              name: 'CARD'
            }, {
              value: 25,
              name: 'SSD'
            }, {
              value: 15,
              name: 'U盘'
            }, {
              value: 8,
              name: '嵌入式'
            }, {
              value: 7,
              name: 'FLASH'
            }],
            label: {
              normal: {
                textStyle: {
                  color: '#999',
                  fontSize: 14
                }
              }
            },
            labelLine: {
              normal: {
                show: false
              }
            },
            itemStyle: {
              normal: {
                borderWidth: 4,
                borderColor: '#ffffff'
              },
              emphasis: {
                borderWidth: 0,
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          }],
          color: [
            '#00acee',
            '#52cdd5',
            '#79d9f1',
            '#a7e7ff',
            '#c8efff'
          ],
          backgroundColor: '#fff'
        })
      },
      drawLine4() {
        let myChart = echarts.init(document.getElementById('myChart4'))
        myChart.setOption({
          color: ['#0099ff'],
          tooltip: {
            trigger: 'axis',
            axisPointer: {            // 坐标轴指示器，坐标轴触发有效
              type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
            }
          },
          grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
          },
          xAxis: [
            {
              type: 'category',
              data: ['冬干冷温', '冬干温暖', '冰原气候', '地中海式', '夏干冷温', '常湿冷温', '常湿温暖', '荒漠气候', '热带季风', '热带干湿季', '热带雨林', '苔原气候', '草原气候'],
              axisTick: {
                alignWithLabel: true
              }
            }
          ],
          yAxis: [
            {
              // type : 'category',
              // data : ['10','20','30','40'],
              axisTick: {
                alignWithLabel: true
              }
            }
          ],
          series: [
            {
              name: '面积统计',
              type: 'bar',
              barWidth: '60%',
              data: [11.43, 22.43, 0.05, 8.83, 6.63, 174.06, 17.82, 28.68, 10.27, 20.35, 10.24, 39.13, 28.63]
            }

          ],
          label: {
            normal: {
              show: true,
              position: 'top',
              formatter: '{c}'
            }
          },
          itemStyle: {
            normal: {

              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                offset: 0,
                color: 'rgba(0, 153, 255, 1)'
              }, {
                offset: 1,
                color: 'rgba(0, 153, 255, 0.1)'
              }]),
              shadowColor: 'rgba(0, 0, 0, 0.1)',
              shadowBlur: 10
            }
          }
        })
      },
      drawLine5() {
        let myChart = echarts.init(document.getElementById('myChart5'))
        myChart.setOption({
          color: ['#0099ff'],
          tooltip: {
            trigger: 'axis',
            axisPointer: {            // 坐标轴指示器，坐标轴触发有效
              type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
            }
          },
          grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
          },
          xAxis: [
            {
              type: 'category',
              data: ['冬干冷温', '冬干温暖', '冰原气候', '地中海式', '夏干冷温', '常湿冷温', '常湿温暖', '荒漠气候', '热带季风', '热带干湿季', '热带雨林', '苔原气候', '草原气候'],
              axisTick: {
                alignWithLabel: true
              }
            }
          ],
          yAxis: [
            {
              // type : 'category',
              // data : ['10','20','30','40'],
              axisTick: {
                alignWithLabel: true
              }
            }
          ],
          series: [
            {
              name: '面积统计',
              type: 'bar',
              barWidth: '60%',
              data: [11.43, 22.43, 0.05, 8.83, 6.63, 174.06, 17.82, 28.68, 10.27, 20.35, 10.24, 39.13, 28.63]
            }

          ],
          label: {
            normal: {
              show: true,
              position: 'top',
              formatter: '{c}'
            }
          },
          itemStyle: {
            normal: {

              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                offset: 0,
                color: 'rgba(0, 153, 255, 1)'
              }, {
                offset: 1,
                color: 'rgba(0, 153, 255, 0.1)'
              }]),
              shadowColor: 'rgba(0, 0, 0, 0.1)',
              shadowBlur: 10
            }
          }
        })
      }
    },
    mounted() {
      this.drawLine()
      this.drawLine2()
      this.drawLine3()
      this.drawLine4()
      this.drawLine5()
      // console.log(this.$route.name)  接收来自子级传递的选项卡name
    }
}
</script>
<style lang='scss'>

  .pgc-audience-property{padding:32px 40px;position:relative;font-size:0}.pgc-audience-property .exponential-content:last-child,.pgc-audience-property .exponential-content:nth-child(2){height:109px}.pgc-audience-property .tui-tab-panel{padding:20px 24px}.pgc-audience-property .exponential-sub-title{line-height:1;font-size:16px;color:#222;margin:20px 0 15px}.pgc-audience-property .exponential-sub-title-first{line-height:1;font-size:16px;color:#222;margin:20px 0 15px;margin:0 0 15px}.pgc-audience-property .exponential-title-wrap{height:43px;line-height:40px;padding-left:20px;font-size:14px;border-bottom:1px solid #e8e8e8}.pgc-audience-property .exponential-content{border:1px solid #e8e8e8;position:relative}.pgc-audience-property .pgc-dashboard{padding:20px 0}.pgc-audience-property .pgc-dashboard .pgc-dashboard-secondary{font-size:16px;color:#222}.pgc-audience-property .pgc-dashboard .pgc-dashboard-secondary .iconfont{margin-left:5px}.pgc-audience-property .tui-pagination-container{margin-top:20px}.pgc-audience-property .content-table{margin-top:20px;border-collapse:collapse;table-layout:fixed;border:1px solid #e8e8e8;font-size:14px;width:100%}.pgc-audience-property .content-table td,.pgc-audience-property .content-table th{padding:10px 12px;border-bottom:1px solid #e8e8e8;text-align:center}.pgc-audience-property .content-table th:first-child{text-align:left}.pgc-audience-property .content-table td{max-width:300px;overflow:hidden}.pgc-audience-property .content-table td:first-child{padding-left:10px;text-align:left}.pgc-audience-property .audience-download-box{text-align:right;margin-top:20px;line-height:1}.pgc-audience-property .audience-download-box a{color:#406599;cursor:pointer}.pgc-audience-property .audience-bar{margin-right:5px;margin-left:5px;padding:25px 20px 20px}.pgc-audience-property .audience-bar .bar-wrap{height:26px;background:#48bfcd;-webkit-border-radius:1px;-moz-border-radius:1px;border-radius:1px;opacity:.8}.pgc-audience-property .audience-bar .bar-inner{width:33%;height:100%;-webkit-transition:width 2s;-moz-transition:width 2s;transition:width 2s;background:#ff7555;text-align:center;color:#fff;line-height:26px}.pgc-audience-property .audience-bar .bar-note{padding-top:20px;width:100%;text-align:right}.pgc-audience-property .audience-bar .bar-note-sharp{width:18px;height:18px;display:inline-block;vertical-align:middle}.pgc-audience-property .audience-bar .bar-note-title{font-size:14px;line-height:18px;content:#666;margin:0 20px 0 5px;vertical-align:middle}.pgc-audience-property .audience-bar .bar-note-title:last-child{margin-right:0}.pgc-audience-property .audience-bar .orange{background:#ff7555}.pgc-audience-property .audience-bar .blue{background:#48bfcd}.pgc-audience-property .audience-age-chart{height:330px;margin-right:180px;overflow:hidden}.pgc-audience-property .audience-age-list,.pgc-audience-property .audience-map-list{height:330px;width:180px;display:inline-block;position:absolute;right:0;top:0;border-left:1px solid #e8e8e8}.pgc-audience-property .audience-age-list .content-table,.pgc-audience-property .audience-map-list .content-table{margin-top:0;border:0}.pgc-audience-property .audience-map-chart{width:600px;margin:10px}.pgc-audience-property .audience-map-pie-chart{margin-right:180px;border-top:1px solid #e8e8e8}.pgc-audience-property .audience-map-list{height:822px}.pgc-audience-property .audience-map-list .audience-map-list-content{overflow-y:auto;height:778px}.pgc-audience-property .interest-media{display:inline-block;padding:18px 5px;-webkit-box-shadow:0 0 3px transparent;-moz-box-shadow:0 0 3px transparent;box-shadow:0 0 3px transparent;margin:0 10px 10px 0;width:115px;height:115px;font-size:14px;color:#555;-webkit-transition:-webkit-box-shadow .3s;transition:-webkit-box-shadow .3s;-moz-transition:box-shadow .3s,-moz-box-shadow .3s;transition:box-shadow .3s;transition:box-shadow .3s,-webkit-box-shadow .3s,-moz-box-shadow .3s;cursor:pointer;-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px;text-align:center;vertical-align:top}.pgc-audience-property .interest-media:hover{-webkit-box-shadow:0 0 7px #999;-moz-box-shadow:0 0 7px #999;box-shadow:0 0 7px #999}.pgc-audience-property .interest-media img{-webkit-border-radius:50%;-moz-border-radius:50%;border-radius:50%;height:50px;width:50px}.pgc-audience-property .interest-media span{line-height:2;display:block;width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.pgc-audience-property .no-data-hint{font-size:30px;font-weight:700;color:#ddd;text-align:center;margin:30px 0}.pgc-audience-property .no-data-hint .emoji{font-size:48px;display:inline-block;margin-bottom:10px}

</style>
