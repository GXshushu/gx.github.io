<template>
    <div id="all">
        all
    </div>
</template>

<script>
export default{
    data() {
        return {

        }
    },
    computed: {

    },
    methods: {

    },
    mounted() {

    }
}
</script>

<style lang='stylus'>
#all{
    padding: 20px 24px;
}
</style>